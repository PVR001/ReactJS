import React from 'react'
import '../styles/Register.css'
import { Link } from 'react-router-dom'
import Lottie from 'react-lottie';
import animationData from '../feed.json';
const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    
    
   
  };

export default function Register() {
  return (
    <div className="register">
        <div className="registerWrapper">
            <div className="registerLeft">
          <h3 className="loginLogo ">Feed.me</h3>
                
                <div className="registerLeftDesc">
                Connect - feed - react<br /> around you
                </div>
            </div>
          <Lottie options={defaultOptions} className="loginLeftDescanim" height={250} width={250} />

            <div className="registerRight">
            <div className="registerBox">
            <form action="" className='registerForm'>
                    <div class="registerUsername">
                        <input className='registerInput' placeholder='Username' type="text" id="username-l"/>
                    </div>
                    <div class="registerEmail">
                        <input className='registerInput' placeholder='Email or Phone number' type="text" id="username-l"/>
                    </div>
                    <div class="registerPassword">
                        <input className='registerInput' placeholder='Password' type="password" id="password-R"/>
                    </div>
                    <div class="registerPassword">
                        <input className='registerInput' placeholder='Retype-password' type="password" id="re-Password-R"/>
                    </div>
                    <div class="registerSubmit">
                        <input id='registerBtn' type="submit" value="Sign Up"/>
                    </div>
                    <hr className="registerHr" />
                    <div class="registerLoginAc">
                    
                        <label for="reg-btn">
                                <Link  style={{textDecoration:'none'}} to="/">
                        <span >Already have a account?</span>
                        </Link>
                        </label>       
                        </div>
                </form>
            </div>
            
        </div>
        </div>
    </div>
  )
}
