import "../styles/Home.css"
import Feed from "../components/Feed";
import Sidebar from "../components/Sidebar"
import Header from "../components/Header";
import Rightbar from "../components/Rightbar"
import Footer from "../components/Footer"



export default function Home({showCreatePost,changeState}) {
 
  return (
     <>
      <div className={showCreatePost?"halfVisualHome":"fullVisualHome"}>

         <Header/>   
        
         <div className="homeContainer">
         <Sidebar/>
         <Feed changeState={changeState}/>
         <Rightbar/>
         </div>
<Footer />
         </div>
    </>
  )
}
