import "../styles/FriendsPage.css";
import Feed from "../components/Feed";
import Sidebar from "../components/Sidebar";
import Header from "../components/Header";

import FriendsRightbar from "../components/FriendsList";
import Footer from "../components/Footer";
import { useParams } from 'react-router-dom';
import { Call, Videocam, CameraAlt } from '@mui/icons-material';



export default function FriendsPage({}) {
  const { firstName, profile_pic_url } = useParams();
  return (
    <>
     <h1>Welcome to the Friends Page, {firstName}!</h1>
      <div className="fullVisualHome">
        <Header />
        <div className="homeContainer">
          <Sidebar />
          <div className="feed"></div>
      <div className="feedWrapper"><div className="friends-chat-container">
 
      <div className="Chatheader">
        <img src={profile_pic_url} alt={`${firstName}'s Profile`} className="profile-image" />
        <div className="user-info">
          <h2>{firstName}</h2>
          4 mins ago
            
             
        </div>
        <div className="chatbarRight">
       
      <Call />
                <Videocam />
              <CameraAlt />
      
        </div>
      
    
      </div>


      <div className="main-content">
       
       
      </div>

      
      <div className="Friendsfooter">
        <input type="text" placeholder="Type a message..." />
        <button>Send</button>
       
      </div>
    </div></div>
          <FriendsRightbar />
        </div>
      
      </div>
    </>
  );
}
