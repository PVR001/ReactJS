import React from "react";
import "../styles/Login.css";
import { Link } from "react-router-dom";
import Lottie from 'react-lottie';
import animationData from '../feed.json';
import { useRef } from "react";
const defaultOptions = {
  loop: true,
  autoplay: true,
  animationData: animationData,
  
  
 
};
export default function Login() {
  const usernameRef = useRef(null);
  const passwordRef = useRef(null);

  const handleLogin = (e) => {
    e.preventDefault();

    
    const enteredUsername = usernameRef.current.value;
    const enteredPassword = passwordRef.current.value;

   
    console.log("Entered Username:", enteredUsername);
    console.log("Entered Password:", enteredPassword);

    

    

  };
  return (
    <div className="login">
      <div className="loginWrapper">
        <div className="loginLeft">
          <h3 className="loginLogo ">Feed.me</h3>
          <div className="loginLeftDesc">
            Connect - feed - react<br /> around you
            
          </div>
          <div >
          <Lottie options={defaultOptions} className="loginLeftDescanim" height={250} width={250} />

          </div>
        </div>
        <div className="loginRight">
          <div className="loginBox">
            <form action="#" className="loginForm">
              <div class="loginUsername">
                <input
                  className="loginInput"
                  placeholder="Email Username"
                  type="text"
                  id="username-l"
                  ref={usernameRef}
                />
              </div>
              <div class="loginPassword">
                <input
                  className="loginInput"
                  placeholder="Password"
                  type="password"
                  id="password-l"
                  ref={passwordRef}
                />
              </div>
              <div class="loginSubmit">
                <Link to="/home">
                  <input id="loginBtn" type="submit" value="Log In" />
                </Link>
              </div>
              <span>
                <a className="forgetPwd" href="#email?">
                  Forgot your password?
                </a>
              </span>
              <hr className="loginHr" />
              <div class="loginCreateAc">
                <Link to="/register">
                  <input
                    className="loginCreateBtn"
                    type="submit"
                    value="Create new account"
                  />
                </Link>
              </div>
            </form>
          </div>
          
        </div>
      </div>
    </div>
  );
}
