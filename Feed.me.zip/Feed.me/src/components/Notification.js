import React from 'react';
import Lottie from 'react-lottie';
import animationData from '../bell.json';
import '../styles/notification.css';
import { Search ,Person ,Notifications} from "@mui/icons-material";
import LiveTvIcon from '@mui/icons-material/LiveTv';
import StorefrontIcon from '@mui/icons-material/Storefront';
import SportsEsportsIcon from '@mui/icons-material/SportsEsports';
import QuestionAnswerIcon from '@mui/icons-material/QuestionAnswer';

const defaultOptions = {
  loop: true,
  autoplay: true,
  animationData: animationData,
  
 
};
const NotificationComponent = () => {
  let notificationCount = 1;

  const increaseNotificationCount = () => {
    setTimeout(() => {
      notificationCount += 1;
      document.getElementById('notificationBadge').innerText = notificationCount;
      increaseNotificationCount();
    }, 3000);
  };

  
  increaseNotificationCount();

  return (
    <><div className="topbarRight">
    <div className="topbarIcons">
      <div className="topbarIconItem">
        <div className="topbarIconCont">
        <Person style={{color:"black",borderRadius:'50%',fontSize:'21px'}} />
        </div>
        <span className="topbarIconBadge">1</span>
      </div>
      <div className="topbarIconItem">
      <div className="topbarIconCont">
      <QuestionAnswerIcon  style={{color:"black",borderRadius:'50%',fontSize:'21px'}}/>
        </div>
        <span className="topbarIconBadge">2</span>
      </div>
      <div className="topbarIconItem">
      <div className="topbarIconCont">
      <Notifications  style={{color:"black",borderRadius:'50%',fontSize:'21px'}}/>
        </div>
        <span className="topbarIconBadge">{notificationCount}</span>
      </div>
    </div>
   
  </div></>
    
  );
};

export default NotificationComponent;
