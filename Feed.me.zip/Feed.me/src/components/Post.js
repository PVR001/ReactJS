import MoreVertIcon from '@mui/icons-material/MoreVert';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import FavoriteIcon from '@mui/icons-material/Favorite';
import TagFacesIcon from '@mui/icons-material/TagFaces';
import SentimentVeryDissatisfiedIcon from '@mui/icons-material/SentimentVeryDissatisfied';
import Lottie from 'react-lottie';
import animationData from '../like.json';
import '../styles/Post.css';
import { Users } from "../data.js";
import { useState } from 'react';
const defaultOptions = {
  loop: true,
  autoplay: true,
  animationData: animationData,
  
 
};


export default function Post({ post, profileImage, username }) {
  const user = Users.find((u) => u.id === post.userId);
  const [reactions, setReactions] = useState({
    like: 0,
    love: 0,
    haha: 0,
    sad: 0,
    angry: 0,
  });
  const [isLiked, setIsLiked] = useState(false);

  const reactionHandler = (reactionType) => {
    setReactions((prevReactions) => ({
      ...prevReactions,
      [reactionType]: prevReactions[reactionType] + 1,
    }));
  };
  
  

  return (
    <div className="post">
      <div className="postWrapper">
        <div className="postTop">
          <div className="postTopLeft">
            <img className='postProfileImage' src={profileImage || user.profilePicture} alt="" />
            <span className="postUsername">{username || user.username}</span>
            <span className="postDate">{post.date}</span>
          </div>

          <div className="postTopRight">
            <MoreVertIcon style={{ cursor: 'pointer' }} />
          </div>
        </div>

        <div className="postCenter">
          <span className="postText">{post.desc}</span>
          <img className='postImage' src={post.photo} alt="" />
        </div>

        <div className="postBottom">
      <div className="postBottomLeft">
        <div style={{display:'flex'}}>
        <div className="likeIconCont">
        <ThumbUpIcon className='likeIcon' onClick={() => reactionHandler('like')} />
        </div>
        <div className="likeIconCont">
        <FavoriteIcon className='likeIcon' onClick={() => reactionHandler('like')} />

 
          </div>
          <div className="likeIconCont">
        <TagFacesIcon className='likeIcon' onClick={() => reactionHandler('like')} />

 
          </div>
          <div className="likeIconCont">
        <SentimentVeryDissatisfiedIcon className='likeIcon' onClick={() => reactionHandler('like')} />

 
          </div>
        </div>
        <span className="postLikeCounter">{reactions.like + reactions.love + reactions.haha + reactions.sad + reactions.angry} people like it</span>
      </div>
      <div className="postBottomRight">
       <span className="postCommentText">{post.comment} comments</span>
      </div>
      </div>
      </div>
    </div>
  );
}
