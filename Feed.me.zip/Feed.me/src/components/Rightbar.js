import React, { useState, useEffect } from "react";
import "../styles/Rightbar.css";
import Friends from "./Friends";
import gift from '../gift.png';
import Lottie from 'react-lottie';
import animationData from '../bday.json';
import addViedo from '../add.mp4'
import 'video-react/dist/video-react.css'; 
import { Player } from 'video-react';
const defaultOptions = {
  loop: true,
  autoplay: true,
  animationData: animationData,
  
 
};

function Rightbar() {
  const [friendList, setFriendList] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchApiData = async () => {
    const url = "https://dummyjson.com/users";

    try {
      const response = await fetch(url);
      const data = await response.json();

      
      const extractedFriendList = data.users.map((user) => ({
        id: user.id,
        profile_pic_url: user.image,
        firstName: user.firstName,
        
      }));

      setFriendList(extractedFriendList);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApiData();
  }, []);

  return (
    <div className="rightbar">
      <div className="rightbarWrapper">
        <div className="birthdayContainer">
          <Lottie options={defaultOptions}  height ={80} width={80} className="birthdayImage" />
          <span className="birthdayText">
            
            <b>Rajesh PV</b> and <b>other friends</b> have a birthday today.
          </span>
        </div>
        <Player muted="true" autoPlay="true"  >
      <source src={addViedo}  />
    </Player>

        <hr className="rightbarHr" />

        <p className="rightbarTitle">Contacts</p>
        <ul className="rightbarFriendList">
        
          {friendList.map((user) => (
            <Friends key={user.id} user={user} />
          ))}
        </ul>
      </div>
    </div>
  );
}

export default Rightbar;
