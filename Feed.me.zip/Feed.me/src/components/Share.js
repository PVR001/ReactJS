import React, { useState } from 'react';
import '../styles/Share.css';
import PermMediaIcon from '@mui/icons-material/PermMedia';
import EmojiEmotionsIcon from '@mui/icons-material/EmojiEmotions';
import VideoCameraBackIcon from '@mui/icons-material/VideoCameraBack';
import Lottie from 'react-lottie';
import toast, { Toaster } from 'react-hot-toast';
import LinearProgress from '@mui/material/LinearProgress';

import animationData from '../addplus.json';
const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    
   
  };

export default function Share({ changeState }) {

  const [isPosting, setIsPosting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [enteredText, setEnteredText] = useState('');
  const notify = () => {

    setIsPosting(true);

    let intervalId = setInterval(() => {
      setProgress((prevProgress) => (prevProgress >= 100 ? 0 : prevProgress + 10));
    }, 200);

    setTimeout(() => {
      clearInterval(intervalId);
      toast.success('Post made', {});
      setIsPosting(false);
      setProgress(0);
    }, 2000);
   
  };

  const handleInputChange = (event) => {
    setEnteredText(event.target.value);
  };

  return (
    <div className='share'>
      {isPosting && <LinearProgress variant="buffer" className='progressBar' value={progress} valueBuffer={100} />}
      <div className="shareWrapper">
        <div className="shareTop">
          <img
            className='shareProfileImage'
            src="https://img.freepik.com/free-photo/young-bearded-man-with-striped-shirt_273609-5677.jpg?size=626&ext=jpg&ga=GA1.1.840996755.1703237863&semt=sph"
            alt=""
          />
          <div className="shareInputCont"></div>
          <input
            placeholder="What's on your mind?"
            onChange={handleInputChange}
            value={enteredText}
            className='shareInput'
          />
        </div>
        <span className='shareButton'>
       <button className='button' onClick={notify} ><Toaster /><Lottie options={defaultOptions}  height={30} width={30} /></button> 
           
           
        </span>
        {/* <button onClick={notify}></button> */}
    
       
        <hr className='shareHr' />
        <div className="shareButtom">
          <div className="shareOptions">
            <div className="shareOption">
              <VideoCameraBackIcon htmlColor='red' className='shareIcon' />
              <span className="shareOptionLongText">Live video</span>
              <span className="shareOptionText">Live</span>
            </div>
            <div className="shareOption">
              <PermMediaIcon htmlColor='green' className='shareIcon' />
              <span className="shareOptionLongText">Photo/video</span>
              <span className="shareOptionText">Gallery</span>
            </div>
            <div className="shareOption">
              <EmojiEmotionsIcon htmlColor='orange' className='shareIcon' />
              <span className="shareOptionLongText">Feeling/Activity</span>
              <span className="shareOptionText">Feel</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
