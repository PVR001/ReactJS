import React from "react";
import Post from "./Post";
import Share from "./Share.js";
import "../styles/Feed.css";
import { Users } from "../data.js"; 

export default function Feed() {
  const customProfileImage = 'path/to/custom/profile/image.jpg';
  const customUsername = 'CustomUsername';

 
  const samplePostPosts = [
    {
      id: 1,
      userId: 1,
      date: '2024-01-05',
      desc: 'This is the first post.',
      photo: 'https://imageio.forbes.com/specials-images/imageserve/5d35eacaf1176b0008974b54/2020-Chevrolet-Corvette-Stingray/0x0.jpg?format=jpg&crop=4560,2565,x790,y784,safe&width=1440',
      comment: 5,
    },
    {
      id: 2,
      userId: 2,
      date: '2024-01-06',
      desc: 'This is the second post.',
      photo: 'https://dubeat.com/wp-content/uploads/2014/11/interstellar.jpg',
      comment: 8,
    },
    {
      id: 3,
      userId: 3,
      date: '2024-01-06',
      desc: 'This is the Third post.',
      photo: 'https://upload.wikimedia.org/wikipedia/en/4/4e/Loki_%28TV_series%29_logo.png',
      comment: 8,
    },
   
  ];

  return (
    <div className="feed">
      <div className="feedWrapper">
      <Share />
      
        {samplePostPosts.map((samplePost) => {
       
          const user = Users.find((u) => u.id === samplePost.userId);

          return (
            <Post
              key={samplePost.id}
              post={samplePost}
              profileImage={user ? user.profilePicture : customProfileImage}
              username={user ? user.username : customUsername}
            />
          );
        })}
      </div>
    </div>
  );
}
