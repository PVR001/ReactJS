// Friends.js
import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Friends.css';

export default function Friends({ user }) {
  return (
    <li className='rightbarFriend'>
      <Link to={`/friends/${user.firstName}`}>
        <div className="rightbarProfileImageCont">
          <img src={user.profile_pic_url} alt="profile" className="rightbarProfileImage" />
          <span className="rightbarOnline"></span>
        </div>
      </Link>
      <span className="rightbarUsername"><b>{user.firstName}</b></span>
    </li>
  );
}
