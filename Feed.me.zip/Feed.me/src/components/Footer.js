
import React from 'react';
import '../styles/Footer.css';

const Footer = () => {
  return (
    <div className="footer">
     
      <p>Feed.me © 2024</p>
    </div>
  );
};

export default Footer;
