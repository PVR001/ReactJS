import "../styles/Header.css";
import Lottie from 'react-lottie';
import animationData from '../bell.json';
import { Search, Person, Notifications } from "@mui/icons-material";
import React, { useState, useEffect } from 'react';
import {Link} from 'react-router-dom';
import DropdownMenu from "./Profilemenu";




import HomeIcon from '@mui/icons-material/Home';
import LiveTvIcon from '@mui/icons-material/LiveTv';
import StorefrontIcon from '@mui/icons-material/Storefront';
import SportsEsportsIcon from '@mui/icons-material/SportsEsports';
import QuestionAnswerIcon from '@mui/icons-material/QuestionAnswer';
import logo from '../png-clipart-facebook-logo-computer-icons-facebook-logo-facebook.png';
import profileImg from '../profileimage.png'

const defaultOptions = {
  loop: true,
  autoplay: true,
  animationData: animationData,
  
 
};

export default function Topbar() {
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  const [notificationCount, setNotificationCount] = useState(1);


  const increaseNotificationCount = () => {
    setNotificationCount((prevCount) => prevCount + 1);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      increaseNotificationCount();
    }, 3000);

    return () => clearInterval(interval);
  }, []); 
  return (
    <>
    <div className="topbarContainer">
      <div className="topbarLeft">
     <p> Feed.me</p>
    
      </div>
      <div className="topbarLeft2">
        <div className="searchbar">
          <Search className="searchIcon" />
          <input
            placeholder="Search "
            className="searchInput"
          />
        </div>
      </div>
      <div className="topbarCenter">
      <div className="topbarLinks">
        <div className="topbarCenterIcon">
          <div  className="topbarHomeIcon">
            <Link to='/home'>
          <HomeIcon style={{fontSize:'30px',color:"blue",position:'relative',  opacity:'0.7'}}/>

            </Link>
          
          </div>
          </div>
          <div className="topbarCenterIcon">
          <LiveTvIcon style={{fontSize:'30px',color:"grey"}}/>
          </div>
          <div className="topbarCenterIcon">
          <StorefrontIcon style={{fontSize:'30px',color:"grey"}}/>
          </div>
          <div className="topbarCenterIcon">
          <SportsEsportsIcon style={{fontSize:'30px',color:"grey"}}/>
          </div>
     
        </div>
      </div>
      <div className="topbarRight">

        <div className="topbarIcons">
        <div
              className="topbarIconItem"
                 >
              <div className="topbarIconCont">
                <Link to="/profile/Rajesh" style={{ textDecoration: 'none' }}>
                  <img
                    src={profileImg}
                    alt=""
                    className="topbarImg"
                    
                  />
                </Link>
              
              </div>
              <span className="topbarIconBadge">1</span>
            </div>
          <div className="topbarIconItem">
          <div className="topbarIconCont">
          <QuestionAnswerIcon  style={{color:"black",borderRadius:'50%',fontSize:'21px'}}/>
            </div>
            <span className="topbarIconBadge">{notificationCount}</span>
          </div>
          <div className="topbarIconItem">
          <div className="topbarIconCont">
          <Lottie options={defaultOptions} className="bell" height={30} width={30} />
        
            </div>
            <span className="topbarIconBadge">{notificationCount}</span>
          </div>
        </div>
       
      </div>
    </div>
    </>
  );
}
