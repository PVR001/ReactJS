import React, { useState, useEffect } from "react";
import "../styles/Rightbar.css";
import Friends from "./Friends";
import gift from '../gift.png';

function FriendsRightbar() {
  const [friendList, setFriendList] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchApiData = async () => {
    const url = "https://dummyjson.com/users";

    try {
      const response = await fetch(url);
      const data = await response.json();

      
      const extractedFriendList = data.users.map((user) => ({
        id: user.id,
        profile_pic_url: user.image,
        firstName: user.firstName,
        
      }));

      setFriendList(extractedFriendList);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApiData();
  }, []);

  return (
    <div className="rightbar">
      <div className="rightbarWrapper">
        

        <p className="rightbarTitle">Friends</p>
        <ul className="rightbarFriendList">
        
          {friendList.map((user) => (
            <Friends key={user.id} user={user} />
          ))}
        </ul>
      </div>
    </div>
  );
}

export default FriendsRightbar;
