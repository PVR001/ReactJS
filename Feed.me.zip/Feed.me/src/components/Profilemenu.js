// DropdownMenu.jsx

import React from 'react';
import { Modal, Button } from 'react-bootstrap';
import '../styles/Profilemenu.css';

const DropdownMenu = ({ handleShow }) => {
  const [show, setShow] = React.useState(false);

  const handleClose = () => {
    setShow(false);
    handleShow(); // Optionally close the dropdown on modal close
  };
  const handleShowModal = () => setShow(true);

  return (
    <>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Dropdown Menu</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <a className="dropdown-item" href="#view-profile" onClick={handleClose}>
            View Profile
          </a>
          <a className="dropdown-item" href="#edit-profile" onClick={handleClose}>
            Edit Profile
          </a>
          <a className="dropdown-item" href="#settings" onClick={handleClose}>
            Settings
          </a>
          <div className="dropdown-divider"></div>
          <a className="dropdown-item" href="#logout" onClick={handleClose}>
            Logout
          </a>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default DropdownMenu;
